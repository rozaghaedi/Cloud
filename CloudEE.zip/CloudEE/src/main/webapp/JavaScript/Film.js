// Function to get all films
function getAllFilms() {
    ajaxResult('FilmServlet?action=getAllFilms', 'output');
}

// Function to get film by ID
function getFilmById(id) {
    ajaxResult('FilmServlet?action=getFilmById&id=' + id, 'output');
}

// Function to insert a new film
function insertFilm() {
    var filmData = {
        title: 'New Film',
        year: 2024,
        director: 'Director',
        stars: 'Stars',
        review: 'Review'
    };
    ajaxPost('FilmServlet?action=insertFilm', filmData, 'output');
}

// Function to update an existing film
function updateFilm() {
    var filmData = {
        id: 1,
        title: 'Updated Film',
        year: 2025,
        director: 'Updated Director',
        stars: 'Updated Stars',
        review: 'Updated Review'
    };
    ajaxPost('FilmServlet?action=updateFilm', filmData, 'output');
}

// Function to delete a film by ID
function deleteFilm(id) {
    ajaxPost('FilmServlet?action=deleteFilm', { id: id }, 'output');
}

// Function to search films by title
function searchFilm(title) {
    ajaxResult('FilmServlet?action=searchFilm&title=' + title, 'output');
}

// Function to make an AJAX GET request
function ajaxResult(address, resultRegion) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {
        showResponseText(request, resultRegion);
    };
    request.open("GET", address, true);
    request.send(null);
}

// Function to make an AJAX POST request
function ajaxPost(address, data, resultRegion) {
    var request = new XMLHttpRequest();
    request.onreadystatechange = function() {
        showResponseText(request, resultRegion);
    };
    request.open("POST", address, true);
    request.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
    request.send(JSON.stringify(data));
}

// Function to handle response from AJAX request
function showResponseText(request, resultRegion) {
    if (request.readyState == 4 && request.status == 200) {
        var response = JSON.parse(request.responseText);
        if (typeof response === 'string') {
            htmlInsert(resultRegion, response);
        } else {
            htmlInsert(resultRegion, JSON.stringify(response));
        }
    }
}

// Function to insert HTML into a specified element
function htmlInsert(id, htmlData) {
    document.getElementById(id).innerHTML += htmlData;
}
