package controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList; 
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.google.gson.Gson;

import model.Film;
import model.FilmDAO;


@WebServlet("/")
public class FilmServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public FilmServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        FilmDAO filmDao = new FilmDAO();
    	ArrayList<Film> filmArray = filmDao.getAllFilms();
        request.setAttribute("fArray", filmArray);
        request.getRequestDispatcher("Film.jsp").forward(request, response);
        
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
        
        
        String action = request.getParameter("action");

        if (action != null) {
            switch (action) {
                case "getAllFilms":
                    getAllFilms(request, response);
                    break;
                case "getFilmById":
                    getFilmById(request, response);
                    break;
                case "insertFilm":
                    insertFilm(request, response);
                    break;
                case "updateFilm":
                    updateFilm(request, response);
                    break;
                case "deleteFilm":
                    deleteFilm(request, response);
                    break;
                case "searchFilm":
                    searchFilm(request, response);
                    break;
                default:
                	response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                    break;
            }
        } else {
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }  
            }
        
   
    private void getAllFilms(HttpServletRequest request, HttpServletResponse response) throws IOException {
        FilmDAO filmDAO = new FilmDAO();
        ArrayList<Film> films = filmDAO.getAllFilms();
        sendResponse(response, films);
    }

    private void getFilmById(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        FilmDAO filmDAO = new FilmDAO();
        Film film = filmDAO.getFilmByID(id);
        sendResponse(response, film);
    }

    private void insertFilm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Retrieve film data from request parameters
        String title = request.getParameter("title");
        int year = Integer.parseInt(request.getParameter("year"));
        String director = request.getParameter("director");
        String stars = request.getParameter("stars");
        String review = request.getParameter("review");

        // Create Film object
        Film film = new Film(); // Instantiate a new Film object
        film.setTitle(title); // Set the title
        film.setYear(year); // Set the year
        film.setDirector(director); // Set the director
        film.setStars(stars); // Set the stars
        film.setReview(review); // Set the review

        // Insert film into database
        FilmDAO filmDAO = new FilmDAO();
        filmDAO.insertFilm(film);

        // Return success response
        sendResponse(response, "Film inserted successfully.");
    }

    private void updateFilm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Retrieve film data from request parameters
        int id = Integer.parseInt(request.getParameter("id"));
        String title = request.getParameter("title");
        int year = Integer.parseInt(request.getParameter("year"));
        String director = request.getParameter("director");
        String stars = request.getParameter("stars");
        String review = request.getParameter("review");

        // Create Film object
        Film film = new Film(id, title, year, director, stars, review);

        // Update film in database
        FilmDAO filmDAO = new FilmDAO();
        filmDAO.updateFilm(film);

        // Return success response
        sendResponse(response, "Film updated successfully.");
    }

    private void deleteFilm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        int id = Integer.parseInt(request.getParameter("id"));
        FilmDAO filmDAO = new FilmDAO();
        filmDAO.deleteFilm(id);
        sendResponse(response, "Film deleted successfully.");
    }

    private void searchFilm(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String title = request.getParameter("title");
        FilmDAO filmDAO = new FilmDAO();
        ArrayList<Film> searchResults = filmDAO.searchFilm(title);
        sendResponse(response, searchResults);
    }
    	

    private void sendResponse(HttpServletResponse response, Object data) throws IOException {
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        out.print(new Gson().toJson(data));
        out.flush();
    }
    }

